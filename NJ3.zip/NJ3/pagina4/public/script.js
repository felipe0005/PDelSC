//funcion para la pagina1
document.getElementById("clickMe").addEventListener('click', () => {
    clickMe.style.backgroundColor = "red";
    clickMe.style.border = "2px solid red";
});

//funcion para la pagina2
document.getElementById("mouse").addEventListener('doubleclick', () =>{
    mouse.style.backgroundColor = "white";
    mouse.style.border = "2px solid blue";
});

//funcion para la pagina3
const menu = document.getElementById("menu");

document.addEventListener("mouseover", () => {
    if (menu) {
        document.getElementById("over").addEventListener("mouseover", () => {
            menu.style.display = "block";
        });
    } else {
        console.error("El elemento con ID 'menu' no existe.");
    }
});

document.addEventListener('mouseout', () => {
    if (menu) {
        document.getElementById("over").addEventListener("mouseout", () => {
            menu.style.display = "none";
        });
    }else{
        console.error("el elemento con ID 'menu' no existe");
    }
})

//funcion para pagina4
document.getElementById("myForm").addEventListener("submit", (e) => {

    e.preventDefault();
    console.log("Formularo enviado");
});