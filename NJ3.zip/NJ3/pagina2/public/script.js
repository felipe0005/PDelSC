function apretar(a){
    window.open(a,'_self')
}