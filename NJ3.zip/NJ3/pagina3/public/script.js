//se crea la funcion que nos permite crear un elemento h1
document.getElementById("btn").addEventListener("click", () => {
    const $h1 = document.querySelector("h1"); 
    if ($h1) {
        document.body.removeChild($h1);
    } else {
        const $nuevoH1 = document.createElement("h1");
        $nuevoH1.textContent = "Presiona devuelta el boton";
        document.body.appendChild($nuevoH1);
    }
});

//se crea la funcion que cambia el texto del h1
document.getElementById("btnC").addEventListener("click", () => {
    const $cambiar = document.querySelector("h1");
    if ($cambiar.textContent === "Texto cambiado") {
        $cambiar.textContent = "Presiona devuelta el boton";
    } else {
        $cambiar.textContent = "Texto cambiado";
    }
});

//se crea la funcion que cambia el color del h1
document.getElementById("btnColor").addEventListener("click", () => {
    const $color = document.querySelector("h1");
    if ($color.style.color === "red") {
        $color.style.color = "black";
    }else{
        $color.style.color = "red";
    }
})

//se crea la funcion que crea un elemento tipo img
document.getElementById("img").addEventListener("click", () => {
    const $img = document.querySelector("img");
    if ($img) {
        document.body.removeChild($img);
    }
    else {
        const $imgNueva = document.createElement("img");
        $imgNueva.src = "https://bluemoji.io/cdn-proxy/646218c67da47160c64a84d5/66b3e58387f7cb984dde9eb7_92.png";
        $imgNueva.style.width = "150px";
        $imgNueva.style.height = "150px";
        $imgNueva.alt = "emoji";
        document.body.appendChild($imgNueva);
    }
})

//se crea la funcion que hace que se cambie la imagen creada anteriormente por otra
document.getElementById("imgCam").addEventListener("click", () => {
    const $imgCambiar = document.querySelector("img");
    $imgCambiar.alt = "emoji2";
    $imgCambiar.src = "https://media.tenor.com/eGIIS3aKoqQAAAAm/yellow-guy-rich.webp";
})

//se crea la funcion que cambia le tamaño de la imagen creada anteriormente
document.getElementById("imgTam").addEventListener("click", () => {
    const $imgTam = document.querySelector("img");
    if ($imgTam) {
        $imgTam.style.width = "200px";
        $imgTam.style.height = "200px";
    } else {
        console.error("No se encontró ninguna imagen para cambiar el tamaño.");
    }
});