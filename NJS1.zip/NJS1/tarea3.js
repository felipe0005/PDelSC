function sumar(a,b){
    return a + b;

}

function restar(a,b){
    return a - b;
    
}

function muti(a,b){
    return a * b;
    
}

function divi(a,b){
    return a / b;
    
}

console.log(sumar(4,5));
console.log(restar(4,5));
console.log(muti(4,5));
console.log(divi(4,5));
