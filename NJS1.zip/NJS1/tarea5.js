import {createServer} from "node:http";
import {sumar,restar,muti,divi} from "./modulo/calculos.js";

const server = createServer((req,res) => {
    res.writeHead(200, { 'Content-Type': 'text/html'});
    res.end(
        `<table>
        <theade>
        <th>Suma</th>
        <th>Resta</th>
        <th>Multiplicacion</th>
        <th>Divicion</th>
        </theade>
        <tbody>
        <th>${sumar(5,9)}</th>
        <th>${restar(15,8)}</th>
        <th>${muti(5,9)}</th>
        <th>${divi(20,5)}</th>
        </tbody>
        </table>`
        );
});

server.listen(3000, '127.0.0.1',() => {
    console.log('listening on http://127.0.0.1:3000')
});