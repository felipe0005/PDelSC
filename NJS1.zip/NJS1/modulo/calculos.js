export function sumar(a,b){
    return a + b;

}

export function restar(a,b){
    return a - b;
    
}

export function muti(a,b){
    return a * b;
    
}

export function divi(a,b){
    return a / b;
    
}
