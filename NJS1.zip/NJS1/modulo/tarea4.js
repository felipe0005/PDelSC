import{sumar,restar,muti,divi} from "./calculos.js"

console.log("La suma es: " + sumar(4,7));
console.log("La resta es: " + restar(2,5));
console.log("la multiplicacion es: " + muti(8,5));
console.log("La division es: " + divi(4,10));
